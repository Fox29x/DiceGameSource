import time
import sys
import random
from random import randint

def game():
    numOfDice = int(input("How many dice would you like to use?" ))
    time.sleep(1.5)
    print("Bills turn:")
    time.sleep(1.5)
    Bill = turn(numOfDice)
    time.sleep(1.5)
    print("Ted's turn:")
    time.sleep(1.5)
    Ted = turn(numOfDice)
    time.sleep(1.5)
    if Bill > Ted:
        print("Bill wins! He had a score of",Bill,"\nTed had a score of",Ted)
        winner = "Bill"
    elif Ted > Bill:
        print("Ted wins! He had a score of",Ted,"\nBill had a score of",Bill)
        winner = "Ted"
    else:
        print("Tie! Both players had a score of",Bill)
        winner = "tie"
    with open("scores.txt","a+") as file:
        file.write(winner+"\n")
        
def RollDice(NumDice):
    num = []
    for i in range(1,NumDice+1):
        a = randint(1, 6)
        print("Rolling dice...\nYou rolled a",a)
        time.sleep(1.5)
        num.append(int(a))
    return num

def sortList(num):
    b = []
    for i in range(1,len(num)+1):
        b.append(max(num))
        num.remove(max(num))
    return ''.join(map(str,b))

def turn(NumDice):
    roll = RollDice(NumDice)
    print("What you rolled:",roll)
    b = sortList(roll)
    print("The biggest number you can make out of your roll is: ",b)
    return b

def stats():
    with open("scores.txt","r+") as file:
        BillWins = []
        TedWins = []
        ties = []
        for i in file:
            if "Bill" in i: BillWins.append(i)
            if "Ted" in i: TedWins.append(i)
            if "tie" in i: ties.append(i)

    print("Bill has won",len(BillWins),"times.\nTed has won",len(TedWins),"times\nThe game has been a tie",len(ties),"times.")
def start():
    a = int(input("What would you like to do?\n1)Play a game of Dice!\n2)Check stats for the game.\n3)Stop playing.\n"))
    if a == 1:
        game()
    if a == 2:
        stats()
    if a == 3:
        sys.exit()
while True:
    start()